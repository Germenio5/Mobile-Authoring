package com.example.agaplinkproject;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.ImageView;
import android.transition.AutoTransition;
import android.transition.TransitionManager;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static final String VALID_NAME = "Juan Dela Cruz";
    private static final String VALID_PASSWORD = "Password1";

    private static final Pattern NAME_PATTERN =
            Pattern.compile("^\\p{L}[\\p{L}.'-]*(\\s+\\p{L}[\\p{L}.'-]*)+$");

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^(09|\\+639)\\d{9}$");

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[A-Z])(?=.*\\d).{8,}$");

    // ---------- Views ----------
    private TextView tabSignIn, tabCreate;
    private View registerForm, loginForm;
    private EditText loginName, loginPassword;
    private EditText regName, regPhone, regPassword;
    private Spinner regBarangay;
    private CheckBox regCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Toggle + forms
        tabSignIn = findViewById(R.id.tabSignIn);
        tabCreate = findViewById(R.id.tabCreate);
        registerForm = findViewById(R.id.registerForm);
        loginForm = findViewById(R.id.loginForm);

        // Login fields
        loginName = findViewById(R.id.loginName);
        loginPassword = findViewById(R.id.loginPassword);

        // Register fields
        regName = findViewById(R.id.regName);
        regBarangay = findViewById(R.id.regBarangay);
        regPhone = findViewById(R.id.regPhone);
        regPassword = findViewById(R.id.regPassword);
        regCheck = findViewById(R.id.regCheck);

        // Toggle clicks
        tabSignIn.setOnClickListener(v -> showForm(false));
        tabCreate.setOnClickListener(v -> showForm(true));
        findViewById(R.id.linkLogIn).setOnClickListener(v -> showForm(false));
        findViewById(R.id.linkRegister).setOnClickListener(v -> showForm(true));

        // Button clicks
        findViewById(R.id.btnRegister).setOnClickListener(v -> attemptRegister());
        findViewById(R.id.btnLogin).setOnClickListener(v -> attemptLogin());

        findViewById(R.id.barangayBox).setOnClickListener(v -> regBarangay.performClick());

        showForm(true); // start on Register

        setupPasswordToggle(regPassword, findViewById(R.id.regPasswordToggle));
        setupPasswordToggle(loginPassword, findViewById(R.id.loginPasswordToggle));

    }

    private void setupPasswordToggle(EditText field, ImageView toggle) {
        // start hidden
        field.setTransformationMethod(PasswordTransformationMethod.getInstance());
        toggle.setImageResource(R.drawable.ic_visibility_off);

        toggle.setOnClickListener(v -> {
            boolean hidden = field.getTransformationMethod() instanceof PasswordTransformationMethod;
            int cursor = field.getSelectionEnd();

            if (hidden) {
                field.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                toggle.setImageResource(R.drawable.ic_visibility);
            } else {
                field.setTransformationMethod(PasswordTransformationMethod.getInstance());
                toggle.setImageResource(R.drawable.ic_visibility_off);
            }
            field.setSelection(cursor); // keep the cursor where it was
        });
    }

    private void showForm(boolean register) {
        AutoTransition transition = new AutoTransition();
        transition.setDuration(125);
        TransitionManager.beginDelayedTransition(findViewById(R.id.formContainer), transition);

        tabCreate.setSelected(register);
        tabSignIn.setSelected(!register);
        registerForm.setVisibility(register ? View.VISIBLE : View.GONE);
        loginForm.setVisibility(register ? View.GONE : View.VISIBLE);
    }

    private void attemptRegister() {
        String name = regName.getText().toString().trim();
        // Remove spaces and dashes so "+63 917 123 4567" becomes "+639171234567"
        String phone = regPhone.getText().toString().replaceAll("[\\s-]", "");
        String password = regPassword.getText().toString();

        regName.setError(null);
        regPhone.setError(null);
        regPassword.setError(null);

        View firstInvalid = null;

        if (!NAME_PATTERN.matcher(name).matches()) {
            regName.setError("Enter your first and last name (letters only)");
            firstInvalid = regName;
        }

        if (!PHONE_PATTERN.matcher(phone).matches()) {
            regPhone.setError("Use 09XXXXXXXXX or +639XXXXXXXXX");
            if (firstInvalid == null) firstInvalid = regPhone;
        }

        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            regPassword.setError("At least 8 characters, 1 number, 1 uppercase letter");
            if (firstInvalid == null) firstInvalid = regPassword;
        }

        if (firstInvalid != null) {
            firstInvalid.requestFocus();
            return;
        }

        if (!regCheck.isChecked()) {
            Toast.makeText(this, "Please Verify if you are a resident in Bacolod", Toast.LENGTH_SHORT).show();
            return;
        }

        String barangay = regBarangay.getSelectedItem().toString();
        Toast.makeText(this,
                "Registered: " + name + " (" + barangay + ")",
                Toast.LENGTH_LONG).show();

        regName.setText("");
        regPhone.setText("");
        regPassword.setText("");
        regCheck.setChecked(false);
        showForm(false);
    }

    private void attemptLogin() {
        String name = loginName.getText().toString().trim();
        String password = loginPassword.getText().toString();

        loginName.setError(null);
        loginPassword.setError(null);

        if (name.isEmpty()) {
            loginName.setError("Enter your full name");
            loginName.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            loginPassword.setError("Enter your password");
            loginPassword.requestFocus();
            return;
        }

        if (name.equalsIgnoreCase(VALID_NAME) && password.equals(VALID_PASSWORD)) {
            Toast.makeText(this, "Welcome, " + VALID_NAME + "!", Toast.LENGTH_SHORT).show();
            // TODO: open the next screen here
        } else {
            Toast.makeText(this, "Incorrect full name or password", Toast.LENGTH_SHORT).show();
        }
    }
}