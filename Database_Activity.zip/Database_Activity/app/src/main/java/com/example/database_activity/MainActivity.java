package com.example.database_activity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    TextView txtRecords;
    EditText edtStudentId;
    EditText edtName;
    EditText edtCourse;
    EditText edtYearLevel;
    Button btnAdd;
    Button btnUpdate;
    Button btnDelete;
    Button btnView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtStudentId = findViewById(R.id.editstudentId);
        edtName = findViewById(R.id.editName);
        edtCourse = findViewById(R.id.editCourse);
        edtYearLevel = findViewById(R.id.editYearLevel);
        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnView = findViewById(R.id.btnView);
        txtRecords = findViewById(R.id.txtRecords);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toFetch();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertData();
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //deleteData();
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //updateData();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void toFetch() {
        try {
            URL url = new URL("http://10.0.2.2/android/androidselect.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            reader.close();

            txtRecords.setText(sb.toString());
            conn.disconnect();

        } catch (Exception e) {
            txtRecords.setText("Error: " + e.getMessage());
        }
    }

    private void insertData() {
        try {
            String studentId = edtStudentId.getText().toString().trim();
            String name = edtName.getText().toString().trim();
            String course = edtCourse.getText().toString().trim();
            String yearLevel = edtYearLevel.getText().toString().trim();

            URL url = new URL("http://10.0.2.2/android/androidinsert.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            String postData = "student_id=" + URLEncoder.encode(studentId, "UTF-8")
                            + "&name=" + URLEncoder.encode(name, "UTF-8")
                            + "&course=" + URLEncoder.encode(course, "UTF-8")
                            + "&year_level=" + URLEncoder.encode(yearLevel, "UTF-8");

            OutputStream os = conn.getOutputStream();

            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8")
            );

            writer.write(postData);
            writer.flush();
            writer.close();
            os.close();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            reader.close();

            txtRecords.setText(sb.toString());
            conn.disconnect();

        } catch (Exception e) {
            txtRecords.setText("Error: " + e.getMessage());
        }
    }

    private void deleteData() {
        try {
            String studentId = edtStudentId.getText().toString().trim();

            if (studentId.isEmpty()) {
                txtRecords.setText("Please enter a Student ID to delete.");
                return;
            }

            URL url = new URL("http://10.0.2.2/android/androiddelete.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            String postData =
                    "student_id=" + URLEncoder.encode(studentId, "UTF-8");

            OutputStream os = conn.getOutputStream();

            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8")
            );

            writer.write(postData);
            writer.flush();
            writer.close();
            os.close();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            reader.close();

            txtRecords.setText(sb.toString());
            conn.disconnect();

        } catch (Exception e) {
            txtRecords.setText("Error: " + e.getMessage());
        }
    }

    private void updateData() {
        try {
            String studentId = edtStudentId.getText().toString().trim();
            String name = edtName.getText().toString().trim();
            String course = edtCourse.getText().toString().trim();
            String yearLevel = edtYearLevel.getText().toString().trim();

            if (studentId.isEmpty()) {
                txtRecords.setText("Please enter a Student ID to update.");
                return;
            }

            URL url = new URL("http://10.0.2.2/android/androidupdate.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            String postData =
                    "student_id=" + URLEncoder.encode(studentId, "UTF-8")
                            + "&name=" + URLEncoder.encode(name, "UTF-8")
                            + "&course=" + URLEncoder.encode(course, "UTF-8")
                            + "&year_level=" + URLEncoder.encode(yearLevel, "UTF-8");

            OutputStream os = conn.getOutputStream();

            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8")
            );

            writer.write(postData);
            writer.flush();
            writer.close();
            os.close();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            reader.close();

            txtRecords.setText(sb.toString());
            conn.disconnect();

        } catch (Exception e) {
            txtRecords.setText("Error: " + e.getMessage());
        }
    }
}