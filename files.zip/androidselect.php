<?php
header("Content-Type: text/plain");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_records_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT fname FROM personsinfo";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo $row["fname"] . "\n";  // Each name on a new line
    }
} else {
    echo "No records found.";
}

$conn->close();
?>
